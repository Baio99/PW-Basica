<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<?php
	//declarar variables
	$codigo=$_POST['codigo'];
	$nombre=$_POST['nombre'];
	
	
	
	echo "Codigo: ".$codigo;
	echo("<br>");
	echo "Nombre: ".$nombre;
	echo("<br>");
	
	
	
	?>
</body>
</html>